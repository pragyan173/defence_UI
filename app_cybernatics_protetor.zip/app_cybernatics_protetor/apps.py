from django.apps import AppConfig


class AppCybernaticsProtetorConfig(AppConfig):
    name = 'app_cybernatics_protetor'
